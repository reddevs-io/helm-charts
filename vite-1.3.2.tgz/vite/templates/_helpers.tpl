{{/*
Expand the name of the chart.
*/}}
{{- define "vite.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "vite.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a docker registry secret
*/}}
{{- define "imagePullSecret" }}
{{- with .Values.imageCredentials }}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"email\":\"%s\",\"auth\":\"%s\"}}}" .registry .username .password .email (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "vite.common.selectorLabels" -}}
app: {{ template "vite.name" . }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "vite.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "vite.labels" -}}
{{ include "vite.selectorLabels" . }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "vite.selectorLabels" -}}
{{ include "vite.common.selectorLabels" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: {{ include "vite.name" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
component: {{ .Values.component | quote }}
helm.sh/chart: {{ include "vite.chart" . }}
tier: {{ .Values.tier | quote }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "vite.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "vite.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create a default fully qualified nodejs name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "vite.nodejs.fullname" -}}
{{- if .Values.nodejs.fullnameOverride }}
{{- .Values.nodejs.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name "nodejs" }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create unified labels for nodejs components
*/}}
{{- define "vite.nodejs.labels" -}}
{{ include "vite.nodejs.selectorLabels" . }}
{{- end }}

{{/*
Selector labels for nodejs
*/}}
{{- define "vite.nodejs.selectorLabels" -}}
{{ include "vite.common.selectorLabels" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/name: {{ include "vite.name" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
component: {{ .Values.nodejs.component | quote }}
helm.sh/chart: {{ include "vite.chart" . }}
tier: {{ .Values.nodejs.tier | quote }}
{{- end }}

{{/*
Create the name of the nodejs service account to use
*/}}
{{- define "vite.nodejs.serviceAccountName" -}}
{{- if and .Values.nodejs.enable .Values.nodejs.serviceAccount.create }}
{{- default (printf "%s-nodejs" (include "vite.fullname" .)) .Values.nodejs.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.nodejs.serviceAccount.name }}
{{- end }}
{{- end }}
