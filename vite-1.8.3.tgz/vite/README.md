# Vite Helm Chart

A Helm chart for deploying Vite applications on Kubernetes with optional Node.js backend support.

## Description

This chart deploys a Vite application using an Nginx web server to serve the static files. It's designed to be simple and lightweight, perfect for frontend applications built with Vite. The chart also supports an optional Node.js backend component for full-stack applications.

## Prerequisites

- Kubernetes 1.19+
- Helm 3.2.0+

## Installing the Chart

To install the chart with the release name `my-vite-app`:

```bash
helm install my-vite-app ./charts/vite
```

## Uninstalling the Chart

To uninstall/delete the `my-vite-app` deployment:

```bash
helm delete my-vite-app
```

## Configuration

The following table lists the configurable parameters of the Vite chart and their default values.

### Basic Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `replicaCount` | Number of replicas | `1` |
| `image.repository` | Image repository | `nginx` |
| `image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `image.tag` | Image tag | `1.28-alpine` |
| `imagePullSecrets` | Image pull secrets | `[]` |
| `nameOverride` | Override the name of the chart | `""` |
| `fullnameOverride` | Override the full name of the chart | `""` |
| `component` | Component label | `vite` |
| `tier` | Tier label | `frontend` |

### Image Credentials Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `imageCredentials.registry` | Private registry server | `""` |
| `imageCredentials.username` | Registry username | `""` |
| `imageCredentials.password` | Registry password | `""` |
| `imageCredentials.email` | Registry email | `""` |

### Environment Variables

| Parameter | Description | Default |
|-----------|-------------|---------|
| `env.normal` | Normal environment variables (key-value pairs) | `[]` |
| `env.secret` | Secret environment variables (key-value pairs) | `[]` |

### Service Account Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `serviceAccount.create` | Create service account | `true` |
| `serviceAccount.automount` | Automount service account token | `false` |
| `serviceAccount.annotations` | Service account annotations | `{}` |
| `serviceAccount.name` | Service account name | `""` |

### Pod Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `podAnnotations` | Pod annotations | `{}` |
| `podLabels` | Pod labels | `{}` |
| `podSecurityContext` | Pod security context | `{}` |

### Security Context

| Parameter | Description | Default |
|-----------|-------------|---------|
| `securityContext.capabilities.drop` | Dropped capabilities | `[ALL]` |
| `securityContext.readOnlyRootFilesystem` | Read-only root filesystem | `true` |
| `securityContext.runAsNonRoot` | Run as non-root user | `true` |
| `securityContext.runAsUser` | User ID to run as | `1000` |

### Service Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `service.type` | Service type | `ClusterIP` |
| `service.port` | Service port | `8080` |

### Network Policy Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `networkPolicy.enabled` | Enable network policy | `true` |
| `networkPolicy.ingress` | Ingress rules | See values.yaml |
| `networkPolicy.policyTypes` | Policy types | `[Ingress]` |

### Ingress Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `ingress.enabled` | Enable ingress | `false` |
| `ingress.className` | Ingress class name | `""` |
| `ingress.annotations` | Ingress annotations | `{}` |
| `ingress.hosts` | Ingress hosts configuration | See values.yaml |
| `ingress.tls` | Ingress TLS configuration | `[]` |

### Gateway API Configuration

The chart supports Kubernetes Gateway API as an alternative to Ingress. This requires Gateway API CRDs to be installed in the cluster.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `gatewayApi.enabled` | Enable Gateway API HTTPRoute for frontend | `false` |
| `gatewayApi.httpRoute.annotations` | HTTPRoute annotations | `{}` |
| `gatewayApi.httpRoute.hostnames` | Hostnames for the route | `[]` |
| `gatewayApi.httpRoute.parentRefs` | Parent Gateway references | `[]` |
| `gatewayApi.httpRoute.backendPort` | Backend service port (defaults to service.port) | `null` |
| `gatewayApi.httpRoute.rules` | Route rules with matches, filters, backendRefs | `[]` |
| `gatewayApi.gateway.create` | Create a Gateway resource | `false` |
| `gatewayApi.gateway.className` | Gateway class name | `""` |
| `gatewayApi.gateway.annotations` | Gateway annotations | `{}` |
| `gatewayApi.gateway.infrastructure` | Gateway infrastructure configuration | `{}` |
| `gatewayApi.gateway.listeners` | Gateway listeners configuration | `[]` |

The HTTPRoute has the same name as the Service: the release fullname (`<release>-vite`, or the release name when it already contains `vite`, or `fullnameOverride`). The backend HTTPRoute is `<fullname>-nodejs`. Policies such as Envoy Gateway's `BackendTrafficPolicy` or `SecurityPolicy` can use that name in their `targetRefs`.

Each entry in `rules` is a Gateway API `HTTPRouteRule` and is rendered as written, so it can carry `matches`, `filters`, `timeouts`, `name` or any other rule field. A rule without `backendRefs` is sent to the chart's Service on `backendPort`, except a rule with a `RequestRedirect` filter: the Gateway API does not allow `backendRefs` next to a redirect, so that rule gets none. An empty `rules` list renders one rule for `PathPrefix /`.

### Resources Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `resources.limits.memory` | Memory limit | `300Mi` |
| `resources.limits.cpu` | CPU limit | Not set |
| `resources.requests.cpu` | CPU request | Not set |
| `resources.requests.memory` | Memory request | Not set |

### Health Probes Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `livenessProbe.httpGet.path` | Liveness probe path | `/` |
| `livenessProbe.httpGet.port` | Liveness probe port | `http` |
| `livenessProbe.initialDelaySeconds` | Initial delay | `10` |
| `livenessProbe.periodSeconds` | Period | `10` |
| `readinessProbe.httpGet.path` | Readiness probe path | `/` |
| `readinessProbe.httpGet.port` | Readiness probe port | `http` |
| `readinessProbe.initialDelaySeconds` | Initial delay | `5` |
| `readinessProbe.periodSeconds` | Period | `5` |
| `startupProbe` | Startup probe (whole block; empty `{}` renders nothing) | `{}` |

The `startupProbe` (added in 1.7.0) is disabled by default — an empty map
renders no probe, so existing releases are unaffected. Set the full block for
apps with a slow first request (e.g. WASM/query-engine warm-up) so the liveness
and readiness probes only start once the app has finished booting:

```yaml
startupProbe:
  httpGet:
    path: /healthz
    port: http
  failureThreshold: 30
  periodSeconds: 2
```

### Autoscaling Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `autoscaling.enabled` | Enable HPA | `false` |
| `autoscaling.minReplicas` | Minimum replicas | `1` |
| `autoscaling.maxReplicas` | Maximum replicas | `100` |
| `autoscaling.targetCPUUtilizationPercentage` | Target CPU utilization | `80` |
| `autoscaling.targetMemoryUtilizationPercentage` | Target memory utilization | Not set |

### Volumes Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `volumes` | Additional volumes | `[]` |
| `volumeMounts` | Additional volume mounts | `[]` |

### Scheduling Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `nodeSelector` | Node selector | `{}` |
| `tolerations` | Tolerations | `[]` |
| `affinity.nodeAffinity` | Node affinity rules | Linux nodes required |
| `affinity.podAntiAffinity` | Pod anti-affinity rules | Prefer different nodes |

### Vite Specific Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `vite.nginxConfig.enabled` | Enable custom nginx configuration | `false` |
| `vite.nginxConfig.config` | Custom nginx configuration content | See values.yaml |

### Init Job Configuration

| Parameter | Description | Default |
|-----------|-------------|---------|
| `initJob.enabled` | Enable init job | `false` |
| `initJob.command` | Command to run in the init container | `""` |
| `initJob.image.repository` | Init job image repository (falls back to `image.repository`) | `""` |
| `initJob.image.tag` | Init job image tag (falls back to `image.tag`) | `""` |
| `initJob.image.pullPolicy` | Init job image pull policy (falls back to `image.pullPolicy`) | `""` |

### Node.js Backend Configuration

The chart supports an optional Node.js backend component. All Node.js parameters are prefixed with `nodejs.*`.

| Parameter | Description | Default |
|-----------|-------------|---------|
| `nodejs.enable` | Enable Node.js backend | `false` |
| `nodejs.replicaCount` | Number of replicas | `1` |
| `nodejs.component` | Component label | `nodejs` |
| `nodejs.tier` | Tier label | `backend` |
| `nodejs.image.repository` | Image repository | `node` |
| `nodejs.image.pullPolicy` | Image pull policy | `IfNotPresent` |
| `nodejs.image.tag` | Image tag | `24-alpine` |
| `nodejs.service.type` | Service type | `ClusterIP` |
| `nodejs.service.port` | Service port | `3000` |
| `nodejs.ingress.enabled` | Enable ingress | `false` |
| `nodejs.ingress.hosts` | Ingress hosts | See values.yaml |
| `nodejs.gatewayApi.enabled` | Enable Gateway API HTTPRoute for backend | `false` |
| `nodejs.gatewayApi.httpRoute.annotations` | HTTPRoute annotations | `{}` |
| `nodejs.gatewayApi.httpRoute.hostnames` | Hostnames for the route | `[]` |
| `nodejs.gatewayApi.httpRoute.parentRefs` | Parent Gateway references | `[]` |
| `nodejs.gatewayApi.httpRoute.backendPort` | Backend service port (defaults to nodejs.service.port) | `null` |
| `nodejs.gatewayApi.httpRoute.rules` | Route rules with matches, filters, backendRefs | `[]` |
| `nodejs.resources.limits.memory` | Memory limit | `300Mi` |
| `nodejs.livenessProbe.httpGet.path` | Liveness probe path | `/health` |
| `nodejs.readinessProbe.httpGet.path` | Readiness probe path | `/health` |

The Node.js backend supports the same configuration options as the frontend (env, serviceAccount, podAnnotations, podLabels, securityContext, networkPolicy, autoscaling, volumes, volumeMounts, nodeSelector, tolerations, affinity).

## Usage Examples

### Basic Deployment

```bash
helm install my-vite-app ./charts/vite
```

### With Custom Image

```bash
helm install my-vite-app ./charts/vite \
  --set image.repository=my-registry/my-vite-app \
  --set image.tag=v1.0.0
```

### With Private Registry

```bash
helm install my-vite-app ./charts/vite \
  --set image.repository=my-registry.com/my-vite-app \
  --set image.tag=v1.0.0 \
  --set imageCredentials.registry=my-registry.com \
  --set imageCredentials.username=myuser \
  --set imageCredentials.password=mypassword \
  --set imageCredentials.email=myemail@example.com
```

### With Environment Variables

```bash
helm install my-vite-app ./charts/vite \
  --set env.normal.API_URL=https://api.example.com \
  --set env.normal.ENVIRONMENT=production \
  --set env.secret.API_KEY=secret-key-here
```

### With Ingress Enabled

```bash
helm install my-vite-app ./charts/vite \
  --set ingress.enabled=true \
  --set ingress.className=nginx \
  --set ingress.hosts[0].host=my-app.example.com \
  --set ingress.hosts[0].paths[0].path=/ \
  --set ingress.hosts[0].paths[0].pathType=Prefix
```

### With Autoscaling

```bash
helm install my-vite-app ./charts/vite \
  --set autoscaling.enabled=true \
  --set autoscaling.minReplicas=2 \
  --set autoscaling.maxReplicas=10 \
  --set autoscaling.targetCPUUtilizationPercentage=70
```

### With Node.js Backend

Deploy a full-stack application with Vite frontend and Node.js backend:

```bash
helm install my-fullstack-app ./charts/vite \
  --set image.repository=my-registry/my-vite-frontend \
  --set image.tag=v1.0.0 \
  --set ingress.enabled=true \
  --set ingress.hosts[0].host=app.example.com \
  --set nodejs.enable=true \
  --set nodejs.image.repository=my-registry/my-node-backend \
  --set nodejs.image.tag=v1.0.0 \
  --set nodejs.ingress.enabled=true \
  --set nodejs.ingress.hosts[0].host=api.example.com
```

### With Custom Nginx Configuration

```bash
helm install my-vite-app ./charts/vite \
  --set vite.nginxConfig.enabled=true \
  --set-file vite.nginxConfig.config=./custom-nginx.conf
```

### With Init Job

```bash
helm install my-vite-app ./charts/vite \
  --set initJob.enabled=true \
  --set initJob.command="echo 'running init'" \
  --set initJob.image.repository=my-registry/my-init-image \
  --set initJob.image.tag=v1.0.0
```

### With Gateway API

Deploy using Kubernetes Gateway API instead of Ingress. This requires Gateway API CRDs to be installed.

```bash
helm install my-vite-app ./charts/vite \
  --set gatewayApi.enabled=true \
  --set gatewayApi.httpRoute.hostnames[0]="app.example.com" \
  --set gatewayApi.httpRoute.parentRefs[0].name=my-gateway \
  --set gatewayApi.httpRoute.parentRefs[0].sectionName=http
```

### With Gateway API and Custom Gateway

Create a Gateway resource along with the HTTPRoute:

```bash
helm install my-vite-app ./charts/vite \
  --set gatewayApi.enabled=true \
  --set gatewayApi.gateway.create=true \
  --set gatewayApi.gateway.className=nginx \
  --set gatewayApi.gateway.listeners[0].name=http \
  --set gatewayApi.gateway.listeners[0].port=80 \
  --set gatewayApi.gateway.listeners[0].protocol=HTTP \
  --set gatewayApi.httpRoute.hostnames[0]="app.example.com" \
  --set gatewayApi.httpRoute.parentRefs[0].name=my-vite-app-gateway \
  --set gatewayApi.httpRoute.parentRefs[0].sectionName=http
```

### With Gateway API for Full-Stack (Frontend + Backend)

Deploy a full-stack application with Gateway API for both components:

```bash
helm install my-fullstack-app ./charts/vite \
  --set image.repository=my-registry/my-vite-frontend \
  --set image.tag=v1.0.0 \
  --set gatewayApi.enabled=true \
  --set gatewayApi.httpRoute.hostnames[0]="app.example.com" \
  --set gatewayApi.httpRoute.parentRefs[0].name=my-gateway \
  --set nodejs.enable=true \
  --set nodejs.image.repository=my-registry/my-node-backend \
  --set nodejs.image.tag=v1.0.0 \
  --set nodejs.gatewayApi.enabled=true \
  --set nodejs.gatewayApi.httpRoute.hostnames[0]="api.example.com" \
  --set nodejs.gatewayApi.httpRoute.parentRefs[0].name=my-gateway
```

### With Gateway API and Advanced Route Rules

Configure advanced routing with path-based matching:

```yaml
# values-gateway.yaml
gatewayApi:
  enabled: true
  httpRoute:
    hostnames:
      - "example.com"
    parentRefs:
      - name: my-gateway
        sectionName: http
    rules:
      - matches:
          - path:
              type: PathPrefix
              value: /api
        backendRefs:
          - name: my-release-nodejs
            port: 3000
      - matches:
          - path:
              type: PathPrefix
              value: /
        backendRefs:
          - name: my-release
            port: 8080
```

```bash
helm install my-app ./charts/vite -f values-gateway.yaml
```

## Building Your Vite App for Kubernetes

To use this chart with your Vite application, you'll need to:

1. Build your Vite app: `npm run build`
2. Create a Docker image with the built files
3. Use that image with this Helm chart

### Example Dockerfile for Vite Frontend

```dockerfile
FROM nginx:1.28-alpine

# Copy built files
COPY dist/ /usr/share/nginx/html/

# Create nginx user and set permissions
RUN chown -R nginx:nginx /usr/share/nginx/html && \
    chmod -R 755 /usr/share/nginx/html && \
    chown -R nginx:nginx /var/cache/nginx && \
    chown -R nginx:nginx /var/log/nginx && \
    touch /var/run/nginx.pid && \
    chown -R nginx:nginx /var/run/nginx.pid

# Use non-root user
USER nginx

# Expose port 8080 (not 80, as we run as non-root)
EXPOSE 8080

# Custom nginx config for non-root
RUN echo 'server { \
    listen 8080; \
    server_name localhost; \
    root /usr/share/nginx/html; \
    index index.html; \
    location / { \
        try_files $uri $uri/ /index.html; \
    } \
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ { \
        expires 1y; \
        add_header Cache-Control "public, immutable"; \
    } \
}' > /etc/nginx/conf.d/default.conf

CMD ["nginx", "-g", "daemon off;"]
```

### Example Dockerfile for Node.js Backend

```dockerfile
FROM node:24-alpine

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production

# Copy application code
COPY . .

# Use non-root user
USER node

# Expose port 3000
EXPOSE 3000

CMD ["node", "server.js"]
```

## Architecture

This Helm chart supports two deployment architectures:

### 1. Frontend Only (Default)
- Deploys a Vite static site served by Nginx
- Suitable for static sites or SPAs that consume external APIs
- Lightweight and simple

### 2. Full-Stack (Frontend + Backend)
- Deploys both Vite frontend and Node.js backend
- Each component has its own deployment, service, and optional ingress
- Backend typically runs on port 3000, frontend on port 8080
- Suitable for applications requiring a custom API backend

## Security Features

The chart includes several security best practices by default:

- **Non-root user**: Containers run as user ID 1000
- **Read-only root filesystem**: Prevents runtime modifications
- **Dropped capabilities**: All Linux capabilities are dropped
- **Network policies**: Enabled by default to control traffic
- **Pod anti-affinity**: Spreads pods across nodes for high availability
- **Service account**: Dedicated service account with automount disabled

## Notes

- The chart uses Nginx 1.28-alpine by default to serve static files
- The nginx configuration includes SPA routing support (fallback to index.html)
- Static assets are cached for 1 year for optimal performance
- Health checks are configured for both liveness and readiness probes
- The default service port is 8080 (not 80) to support non-root containers
- Network policies are enabled by default for enhanced security
- When using the Node.js backend, ensure your backend exposes a `/health` endpoint for health checks
